const {
  rp,
  requestPage,
  cheerio,
  iconv,
  tool,
  log,
  db
} = require("../tool/require");
const reptileCommon2 = require("./common/reptileCommon");

/*
 * 通过 url 获取
 * 获取书的目录
 * 并生成json格式
 * */
async function getBookCatalogJson_common(
  reptileType,
  url,
  callback,
  errorback
) {
  await startRp();
  async function startRp() {
    let result = null;
    let start = 0;
    let error = null;
    let reptileCommon = await reptileCommon2();
    while (!result && start <= 5) {
      start++;
      let option = {
        url: url,
        transform: body => {
          return cheerio.load(body, { decodeEntities: false });
        }
      };
      try {
        $ = await requestPage(option);
        let title = reptileCommon.bookTitle($); //reptileCommon.bookTitle($);
        let author = $("#info>p:first-child").html(); //reptileCommon.bookAuthor($);
        //let updateTime = reptileCommon.getUpdateTime($);
        //let description = reptileCommon.getDescription($);
        //let imgUrl = reptileCommon.getBookImgUrl($);
        ///let baseUrl = tool.getHost(url);
        // let bookType = "reptileCommon.getBookType($)";
        // let bookStatus = 1; //1表示连载 2表示完本
        // //获取三天之前的时间
        // let date = reptileCommon.beforeThreeDay();
        console.log("title", title, author);
        // let book = {
        //   title,
        //   author,
        //   description,
        //   imgUrl,
        //   baseUrl,
        //   url,
        //   updateTime,
        //   bookType,
        //   bookStatus,
        //   reptileType
        // };
        // result = { title: title };
      } catch (err) {
        console.log(err);
      }
    }
  }
}
getBookCatalogJson_common(
  1,
  "https://www.biquge5200.cc/46_46337/",
  res => {
    console.log(res);
  },
  err => {
    console.log(err);
  }
);

module.exports = async (reptileType, url, callback, errorback) => {
  reptileType = parseInt(reptileType);
  return getBookCatalogJson_common(reptileType, url, callback, errorback);
};
