const common = require("../../common/tool/require")
module.exports = common;
