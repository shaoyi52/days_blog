let fs = require("fs");
let cheerio = require("cheerio");
let request = require("request");
//let iconv = require("iconv");
let iconv = require('iconv-lite');
module.exports = {
	cheerio,
	fs,
	request,
	iconv
}