/*
* 允许访问的域名host
* */
module.exports = [
    'localhost:1111',
    'localhost:3000',
    'localhost:9092',
    'localhost:8000',
    'localhost:8080',
]