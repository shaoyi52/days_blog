//const request = require("request");
//const userAgents = require("./user-agent.js");
const superagent = require("superagent");
const { cheerio, iconv } = require("./require");
require("superagent-charset")(superagent);
//const Agent = require("http").Agent;
//request(reqOptions, function(error, response, body) {});
/**
 *
 * @param {url:采集页,charset:页面编码，transform：返回数据处理} option
 */
const requestPage = function(option) {
  return new Promise(async (resolve, reject) => {
    let res = superagent
      .get(
        option.url
        //"https://www.biquge5200.cc/modules/article/search.php?searchkey=%E9%AA%B7%E9%AB%85%E7%B2%BE%E7%81%B5"
      )
      .charset("gbk")
      .end(function(err, res) {
        if (err) {
          reject(err);
          //console.log(err);
        } else {
          //console.log(res.status, res.headers);
          //console.log(res.text);

          let $ = option.transform(res.text);
          resolve($);
        }
      });
  });
};

module.exports = requestPage;
