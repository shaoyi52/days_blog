var server = require("./spider");

server.start();